function olamundo(){
    var nome = "Ramon";
    var ano = 2019;
    var ano_nascimento = 1985;
    var idade= ano - ano_nascimento;
    alert("Ola " + nome + ", você tem "+ idade +"anos.");
}